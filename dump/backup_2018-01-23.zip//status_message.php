 <?php
require_once 'connectsql.php'; // подключаем скрипт
 $data = $_POST["data"];
 $sql = "UPDATE message SET state='1' WHERE id='".$data."'";
 if(mysqli_query($connect, $sql))
 {
      echo 'Данные Обновлены';
 }
 ?>