<?php
require 'connect.php';
 if(isset($_POST["data_id"]))
 {
  $beans = R::getAll('SELECT krossdata.id, krossdata.data, krossdata.raspred_id, raspred.raspred_name, krossdata.number, krossdata.sub_id, sub.sub_name, krossdata.type_id, type.type_name, krossdata.comment, krossdata.area_id, area.area_name
FROM krossdata
INNER JOIN sub ON krossdata.sub_id = sub.id
INNER JOIN type ON krossdata.type_id = type.id
INNER JOIN area ON krossdata.area_id = area.id
INNER JOIN raspred ON krossdata.raspred_id = raspred.id
WHERE krossdata.data=?  AND area.area_name=?', [$_POST["data_id"], $_POST["area"]]);
  foreach($beans as $row){
      echo json_encode($row);
    }
 }
 ?>