<?php
require 'connect.php';
$output='';
//$data=htmlspecialchars($_POST);
$tablename = $_POST['tablename'];
$columnname = $_POST['columnname'];
$name = $_POST['name'];
$beans=R::getAll( 'SELECT * FROM '.$tablename.'');
// echo('<pre>');
// print_r($beans);
// echo('</pre>');
$output= '
       <div class="table-responsive" id="employee_table">
       <h3>Таблица '.$name.'</h3>
           <table class="table table-bordered table-hover header-fixed table-fixed">
           <thead>
                <tr>
                    <th>ID</th>
                     <th>'.$name.'</th>

                </tr>
                </thead>
                <tbody>';
foreach ($beans as $row) {
    $output .= '
                <tr class="w3-aqua">

                     <td>'.$row['id'].'</td>
                     <td><a href="#"  data-nametable="'.$name.'" data-idname="'.$row['id'].'" class="tablecolumn">'.$row[$columnname].'</a></td>
                </tr>
           ';
}
echo($output);
?>