<?php
require 'connect.php';
$output = '';
$searchString=htmlspecialchars($_POST['searchString']);
$tablename=htmlspecialchars($_POST['tablename']);
$columnname=htmlspecialchars($_POST['columnname']);
$beans = R::getAll('SELECT krossdata.data, krossdata.raspred_id, raspred.raspred_name, krossdata.number, krossdata.sub_id, sub.sub_name, sub.id, type.type_name, krossdata.comment, area.area_name
FROM krossdata
INNER JOIN raspred ON krossdata.raspred_id = raspred.id
INNER JOIN sub ON krossdata.sub_id = sub.id
INNER JOIN type ON krossdata.type_id = type.id
INNER JOIN area ON krossdata.area_id = area.id
WHERE '.$tablename.'.'.$columnname.'=?', [ $searchString ]);

//echo $output;
$catalogBeans=R::getAll('SELECT catalog.id, sub.sub_name, catalog.vnutr, catalog.city, unit.unit_name, department.department_name, catalog.cabinet, filial.filial_name, catalog.visibility
FROM catalog
INNER JOIN sub ON catalog.sub_id = sub.id
INNER JOIN unit ON catalog.unit_id = unit.id
INNER JOIN department ON catalog.department_id = department.id
INNER JOIN filial ON catalog.filial_id = filial.id
WHERE '.$tablename.'.'.$columnname.'=?', [ $searchString ]);

if ($beans==null & $catalogBeans==null) {
	$output='';
	$output='<div class="alert alert-success">Значение <strong>'.$searchString.'</strong> не задействовано ни в Кроссовом журнале, ни в Справочнике. Удаление возможно.</div>';
} else {
	if ($beans==null){
		$output=''; $output='<br><h4>Данные кросса</h4><div class="alert alert-success">Значение <strong>'.$searchString.'</strong> в Кроссовом журнале не задействовано.</div>';
}
else {
	$output='<br><h4>Данные кросса</h4><div class="alert alert-danger">Привязано к данным. Попытка удаления приведет к установке значения <strong>'.$searchString.'</strong> в затрагиваемых данных на <strong>Не присвоено</strong>!
</div>';
}
if ($catalogBeans==null){$output.='<br><h4>Данные Справочника</h4><div class="alert alert-success">Значение <strong>'.$searchString.'</strong> в Каталоге не задействовано.</div>';}
else {
	$output.='<br><h4>Данные Справочника</h4><div class="alert alert-danger">Привязано к данным Каталога. Попытка удаления приведет к установке значения <strong>'.$searchString.'</strong> в затрагиваемых данных Каталога на <strong>Не присвоено</strong>!
</div>';
}
}

echo $output;
?>