<?php
//fetch.php
require 'connect.php'; // подключаем скрипт
// $connect = mysqli_connect("localhost", "root", "", "testing");
$output = '';
if(isset($_POST["query"]))
{
$search = $_POST["query"];
  $logkross=R::getAll('SELECT * FROM logcatalog WHERE logcatalog.catalog_id LIKE ? OR logcatalog.sub LIKE ? OR logcatalog.vnutr LIKE ? OR logcatalog.unit LIKE ? OR logcatalog.department LIKE ? OR logcatalog.cabinet LIKE ? OR logcatalog.filial LIKE ? OR logcatalog.visibility LIKE ? OR user LIKE ? OR operation LIKE ? ORDER BY id DESC', ['%' .$search. '%', '%' .$search. '%', '%' .$search. '%', '%' .$search. '%', '%' .$search. '%', '%' .$search. '%', '%' .$search. '%', '%' .$search. '%', '%' .$search. '%', '%' .$search. '%']);
 // $search = mysqli_real_escape_string($connect, $_POST["query"]);
 // $query = "
  // SELECT * FROM tbl_customer 
  // WHERE CustomerName LIKE '%".$search."%'
  // OR Address LIKE '%".$search."%' 
  // OR City LIKE '%".$search."%' 
  // OR PostalCode LIKE '%".$search."%' 
  // OR Country LIKE '%".$search."%'
 // ";
}
else
{

  $logkross=R::getAll('SELECT * FROM logcatalog ORDER BY id DESC LIMIT 100');

}
if($logkross!=null){
   $output .= '
  <div class="table-responsive">
   <table class="table table bordered">
<tr>
<th>ID</th>
<th>Дата</th>
<th>ID Абонента</th>
<th>Абонент</th>
<th>Телефон</th>
<th>Управление</th>
<th>Отдел/Бюро</th>
<th>Кабинет</th>
<th>Филиал</th>
<th>Видимость</th>
<th>Оператор</th>
<th>Операция</th>
</tr>
 ';
  foreach($logkross as $row)
 {

 $output .= '
   <tr>
    <td>'.$row["id"].'</td>
  <td>'.$row["datechange"].'</td>
  <td>'.$row["catalog_id"].'</td>
  <td>'.$row["sub"].'</td>
  <td>'.$row["vnutr"].'</td>
  <td>'.$row["unit"].'</td>
  <td>'.$row["department"].'</td>
  <td>'.$row["cabinet"].'</td>
  <td>'.$row["filial"].'</td>
  <td>'.$row["visibility"].'</td>
  <td>'.$row["user"].'</td>
  <td>'.$row["operation"].'</td>
   </tr>
  ';
 }
 echo $output;
}
else
{
 echo 'Data Not Found';
}

?>