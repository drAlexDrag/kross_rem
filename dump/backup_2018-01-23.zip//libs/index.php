<?php
require "rb.php";

R::setup( 'mysql:host=localhost;dbname=rb_kross',
        'dron', 'port2100' ); //for both mysql or mariaDB
if (!R::testConnection()) {
	# code...
} else {
	echo('Соединение OK');
	echo '<br>';
	echo '<br>';
	
}

$user=R::loadAll('area', array());

 foreach($user as $usa)
 {
 	echo $usa->name;

 	echo '<br>';
 }

 
?>