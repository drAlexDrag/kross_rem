$(document).ready(function(){
  if (($('#adm').text())!=1){
    $(".admin").remove();}
    fetchData(1);
    $('#dataKross').tooltip({title: 'Данные <span class="colortext"></span>', container_p: ".modal-body", placement: "top", html: true});
    $('#dataRaspred').tooltip({title: "Выбираем : <span class='colortext'>Входящие/Исходящие</span>", container_p: ".modal-body", placement: "top", html: true});
    $('#dataNumber').tooltip({title: "Номер <span class='colortext'>телефона</span>", container_p: ".modal-body", placement: "top", html: true});
    $('#dataSub').tooltip({title: "Выбрать <span class='colortext'>имя</span> из списка. Или ввести новое имя абонента. Оно автоматически будет добавлено в список. <span style='color:blue'>Для редактированя имени абонента необходимо перейти в соответствующее меню.</span><span class='colortext'>При вводе нового имени НЕОБХОДИМО УКАЗАТЬ ТОЛЬКО НАИМЕНОВАНИЕ АБОНЕНТА ВСЮ ОСТАЛЬНУЮ ИНФОРМАЦИЮ, МОЖНО УКАЗАТЬ В КОММЕНТАРИЯХ</span>", container_p: ".modal-body", placement: "top", html: true});
    $('#dataType').tooltip({title: "Тип <span class='colortext'>связи</span> можно выбрать из списка", container_p: ".modal-body", placement: "top", html: true});
    $('#dataComment').tooltip({title: "Любая <span class='colortext'>полезная или не полезная информация</span>", container_p: ".modal-body", placement: "top", html: true});

    // $('#catalogId').tooltip({title: "Присваивается <span class='colortext'>автоматически</span>", container_p: ".modal-body", placement: "top", html: true});
    // $('#catalogVisibility').tooltip({title: "Видимость абонента в каталоге", container_p: ".modal-body", placement: "top", html: true});
    // $('#catalogSub').tooltip({title: "Редактируем <span class='colortext'>имя</span> абонента в справочнике", container_p: ".modal-body", placement: "top", html: true});
    // $('#catalogVnutr').tooltip({title: "Редактируем <span class='colortext'>внутренние номера</span> абонента в справочнике", container_p: ".modal-body", placement: "top", html: true});
    // $('#catalogCity').tooltip({title: "Редактируем <span class='colortext'>городские номера</span> абонента в справочнике", container_p: ".modal-body", placement: "top", html: true});
    // $('#catalogUnit').tooltip({title: "Редактируем <span class='colortext'>наименование управление</span> абонента в справочнике. Можно выбрать из имеющихся", container_p: ".modal-body", placement: "top", html: true});
    // $('#catalogDepartment').tooltip({title: "Редактируем <span class='colortext'>наименование отдела или бюро</span> абонента в справочнике. Можно выбрать из имеющихся", container_p: ".modal-body", placement: "top", html: true});
    // $('#catalogCabinet').tooltip({title: "Редактируем <span class='colortext'>номер кабинета/помещения</span> абонента", container_p: ".modal-body", placement: "top", html: true});
    // $('#catalogFilial').tooltip({title: "Редактируем <span class='colortext'>наименование филиала</span> абонента. Можно выбрать из имеющихся", container_p: ".modal-body", placement: "top", html: true});


    // $('[data-toggle="tooltip"]').tooltip();

 });////////////////////


//Pagination pagination.php
$(document).on('click', 'li.page-item, a.page-link',function(){//$(document).on('click', 'li.active',function(){
  var page = $(this).attr('p');
  var www =$('.headerPage').attr("data-www");
  console.log("pagin", www);
  if (www=="redaktorCatalog") {catalogEdit(page);} 
  else if (www=="logKross") {readLogData(page);}
  else if (www=="logCatalog") {readLogCatalog(page);}
  else {fetchData(page);}
  //var page = $(this).attr('p');
  //fetchData(page);
});
$(document).on('click', '#go_btn',function(){
  var page = parseInt($('.goto').val());
  var no_of_pages = parseInt($('.total').attr('a'));
  if(page != 0 && page <= no_of_pages){
    var www =$('.headerPage').attr("data-www");
    console.log("pagin", www);
    if (www=="redaktorCatalog") {catalogEdit(page);} 
    else if (www=="logKross") {readLogData(page);}
    else if (www=="logCatalog") {readLogCatalog(page);}
    //fetchData(page);
    else{fetchData(page);}
  }else{
    alert('Введите номер между 1 и '+no_of_pages);
    $('.goto').val("").focus();
    return false;
  }
});
//Pagination END


function func() {
 // $('#perevorot').toggleClass('hover');
  $("#countbid").remove();
      // $("#counthref").val(' ');
      $.ajax({
        url: "countbid.php",
        cache: false,
        dataType:"html",
        success: function(data){

          $("#counthref").append('<span class="badge" id="countbid">'+data+'</span>');
          // $('#perevorot').toggleClass('hover', true);
          // setTimeout(function_delay(), 5000);

      }
    });

    }

    // setInterval(func, 60000);




//Вывод на печать
$(document).on('click', '#printt', function(){
 Popup($('.table-responsive').html());

});
//Вывод на печать
//Вывод на печать
function Popup(data)
{
  var mywindow = window.open('', 'my div', 'height=700,width=1200');
  mywindow.document.write('<html><head><title>Печать текущей страницы</title>');
        /*optional stylesheet*/ //mywindow.document.write('<link rel="stylesheet" href="main.css" type="text/css" />');
        mywindow.document.write('</head><body >');
        mywindow.document.write('<div><h3>Кроссовый журнал</h3></div>');
        mywindow.document.write(data);
        mywindow.document.write('</body></html>');
        mywindow.document.close(); // necessary for IE >= 10
        mywindow.focus(); // necessary for IE >= 10
        mywindow.print();
        mywindow.close();
        return true;
      }

//EXIT

function exitKross(data){
  if(confirm("Вы действительно хотите завершить работу?")){
    $.ajax({
      url: "logout.php",
      cache: false,
      success: function(html){
        $("body").html(html);
      }
    });
  }
}

function fetchData(page)
{
  $("#message_area").detach();
  // $('.spr').show();
  $('#area').show();
  // $('#spr_r').show();
  $('#top_content_right').show();
  $('#top_content_right2').show();
  $('#top_content').show();
  $('#top_bottom').show();
  var area=paramArea()[0];
  var areaId=paramArea()[1];
  header='<nav class="navbar navbar-default">\
  <div class="container-fluid">\
  <div class="navbar-header">\
  <a href="#"><h4>Поиск по данным '+area+'</h4></a>\
  </div>\
  <ul class="nav navbar-nav navbar-right">\
  <li><a href="#" onclick="dataCRUD()">Добавить данные</a></li>\
  <!--li><a href="#">Page 1</a></li>\
  <li><a href="#">Page 2</a></li>\
  <li><a href="#">Page 3</a></li-->\
  </ul>\
  </div>\
  </nav>';
  $.ajax({
    url:"select.php",
    method:"POST",
    data:{area:area, page:page},
    dataType:"html",
    success:function(data)
    {
      $('#container_p').html(data);
      $('#top_header_left').html(header);
    },
    error:function(data)
    {
      $('#top_header_left').html("Ошибка соединения");
    }
  });
  $.ajax({
    url: 'poisk_form.php',
    success: function(data) {
      $('#poisk').html(data);
    }
  });
// func();
}

function paramArea(){
  var area = [("param_area", param_area.value), $('#param_area').find(':selected').attr('data-id')];
  console.log("ID AREA", area[1]);
  console.log("AREA", area[0]);
  return (area);
}

//работа с таблицами
function staCRUD(tablename, nameQ) {
  console.log("loger", tablename);
  console.log("loger", nameQ);
  var columnname=tablename+"_name";
  var name=nameQ;
  $("#buttonUpdate").hide();
  $("#buttonExecute").show();
  $('#staCrudForm')[0].reset();
  $("#result").remove();
  document.getElementById('staCrudTitle').innerHTML=("Работа с таблицей: "+name);
  document.getElementById("labelheader").innerHTML=("Выбранное значение будет обновлено:");
  document.getElementById("out").innerHTML='';
  $("#tablename").val(tablename);
  $("#columnname").val(columnname);
  $('#staCrudModal').modal('show');
  name_div = document.getElementById("outCrudModal").getAttribute("id");
  dataViewTable(name_div, tablename, columnname, name);
  $('#headername').val(name);
  document.getElementById("staAutoList").setAttribute('data-table', tablename);
  console.log("Атрибут data-table до: ", document.getElementById("staAutoList").getAttribute("data-table"));
  console.log("Начальная загрузка таблицы: ", tablename);
  console.log("Атрибут data-table после: ", document.getElementById("staAutoList").getAttribute("data-table"));
  console.log("loger", name);
  console.log("loger", columnname);
  console.log("loger", tablename);
}

$(document).on('change', '#newValue', function () {
        var val = this.value|0; // to int
        
        if (this.checked) {
          document.getElementById("labelheader").innerHTML=("Набраное значение будет добавлено в таблицу:"); 
        } 
        else {
          document.getElementById("labelheader").innerHTML=("Выбранное значение будет обновлено:");
        }
      });

function staExecute() {
  event.preventDefault();
  if($('#staAutoList').val() == "")
  {
    alert("Пустое значение");
  }
  else {
    if ($("#newValue").prop('checked')){
      $('#idname').val('');
    }
    $("#buttonExecute").show();
    var tablename = $('#tablename').val();
    var columnname = $('#columnname').val();
    var newvalue=$('#staAutoList').val();
    var name=$('#headername').val();
    var idname=$('#idname').val();
    $.ajax({
     url:"staexecute.php",
     method:"POST",
     data:{tablename:tablename, columnname:columnname, newvalue:newvalue, name:name, idname:idname},
     success:function(data)
     {

       $('#newValue').prop('checked', false);
       // document.getElementById("out").innerHTML
       document.getElementById("out").innerHTML="";
       $('#staAutoList').val("");
       $('#result').html(data);
       $('#myModal').modal('show');

     }
   });
  }
}

function closeMyModal(){
  $('#myModal').modal('hide');
}

function staDelete(){
  $('#staDeleteForm')[0].reset();
  document.getElementById("idLabelDelete").innerHTML='Id #:'+$("#idname").val()+'<br>'+$("#staAutoList").val();// id записи в таблице '+$('#headername').val()+' 
  document.getElementById("titleDelete").innerHTML='Информация будет удалена из таблицы <span class="label label-info">\
  '+$('#headername').val()+'</span>\
  <span class="label label-danger">Без возможности восстановления</span>';
  $('#myModalDelete').modal('show');
  var paramPoisk="sub_name";
  var searchString=$("#staAutoList").val();
  var tablename=$("#tablename").val();
  var columnname=$("#columnname").val();
  $.ajax({
    url:"delete_select.php",
    method:"POST",
    data:{searchString:searchString, tablename:tablename, columnname:columnname},
    dataType:"html",
    success:function(data){
      $("#outDelete").html(data);
    }
  });
  
}

function deleteEntry(){
  var idname=$("#idname").val();
  var tablename=$("#tablename").val();
  var columnname=$("#columnname").val();
  $.ajax({
    url:"stadelete.php",
    method:"POST",    data:{idname:idname, tablename:tablename, columnname:columnname},
    dataType:"html",
    success:function(data){
      $("#idLabelDelete").html(data);
      $("#outDelete").html('');
    }
  });
}

function closeMyModalDelete(){
  $('#myModalDelete').modal('hide');
}

function updateStaData(staname) {
  var nameselect=$(staname).text();
  var idname=staname.getAttribute('data-idname');
  var nametable=staname.getAttribute('data-nametable');
  $('#staAutoList').val(nameselect);
  $('#idname').val(idname);
  console.log('Имя выбранное из таблицы', idname, '-', nameselect);
  console.log('Таблица-----------------', nametable);
  document.getElementById("out").innerHTML="<p style='color: blue' id='xxx'>Обрабатываем значение : "+nameselect+"</p><p style='color: red'>"+idname+"</p>";
  var idvariable='#'+nametable+'Id';
  $(idvariable).val(idname);

}


//работа с таблицами //

//обработка таблицы krossdata
//MODAL Окно редактирования
$(document).on('click', '.edit_data', function(){
  $("#result").remove();
  $('#dataCrudForm')[0].reset();
  var login = $('#login').text();
  var data_id = $(this).data("idxxx");
  var area=$(this).data("idarea");
  $.ajax({
    url:"datafetchupdate.php",
    method:"POST",    data:{data_id:data_id, area:area},
    dataType:"json",
    success:function(data){
      $('#dataCrudTitle').html("Редактируем данные №: "+data.data+" кросса "+area);
      $('#dataKross').val(data.data);
      $('#dataKross').attr('readonly', true);
      $('#dataRaspred').val(data.raspred_name);
      $('#dataNumber').val(data.number);
      $('#dataSub').val(data.sub_name);
      $('#dataType').val(data.type_name);
      $('#dataComment').val(data.comment);
      $('#previousSubId').val(data.sub_id);/////////////////
      $('#areaName').val(data.area_name);
      $('#dataId').val(data.id);
      $('#subId').val(data.sub_id);
      $('#raspredId').val(data.raspred_id);
      $('#typeId').val(data.type_id);
      $('#areaId').val(data.area_id);
      $('#loginName').val($('#login').text());
      $('#buttonDataExecute').text("Обновить");
      $('#buttonDataClear').text("Очистить");
      $('#dataCrudModal').modal('show');
      console.log("LogKross", "modal('show')");

    }
  });
});
//
function dataCRUD() {
  var area=paramArea()[0];
  var areaId=paramArea()[1];
  $("#result").remove();
  $('#dataCrudForm')[0].reset();
  $('#insert').val("Вставить");
  $('#dataKross').attr('readonly', false);
  $('#areaName').val(area);
  $('#areaId').val(areaId);
  $('#loginName').val($('#login').text());
  $('#dataList').html("");
  $('#numberList').html("");
  $('#move_data_btn').hide();
  $('#delete_btn').hide();
  $('#dataCrudTitle').html("Добавить данные на "+area);
  $('#data_data').removeAttr('readonly');
  $('#buttonDataExecute').text("Вставить");
  $('#buttonDataClear').text("Очистить");
  $('#dataCrudModal').modal('show');
  console.log("LogKross", area);
  console.log("LogKross", "insertNewData()");
}

function dataViewTable(name_div, tablename, columnname, name) {
  name_div='#'+name_div;
  $.ajax({
   url:"loadfetch.php",
   method:"POST",
   data:{tablename:tablename, columnname:columnname, name:name},
   success:function(data)
   {
    $(name_div).after("<div id='result' name='result' style='height:300px;overflow-y:scroll;'></div>");
    $('#result').html(data);
  }
});
}
function dataClear() {
  if (confirm("Данные будут очищены и помечены как свободные")) {
    $('#dataNumber').val("");
    $('#dataSub').val("");
    $('#dataType').val("Свободный");
    dataExecute();
  } else {
  //alert("В");
}
}
 // function myAlert(varHTML, tablename, runame) {

 //  $("#perehod").remove();
 //   $('#myAlert').modal('show');
 //   document.getElementById("alertdialog").innerHTML=varHTML;
 //   $('<button type="button" class="btn btn-default" data-dismiss="modal" id="perehod">Добавить значение в таблицу</button>').insertAfter("#alertdialog");
 //   document.getElementById("perehod").onclick = function() {staCRUD(tablename, runame)};
 // }
 function dataExecute() {
  event.preventDefault();
  if($('#dataKross').val() == "")
  {
    alert("Введите данные");
  }
  else if($('#raspredId').val() == '')
  {
    alert("Выберите распределение");
    // varHTML='Значение отсутствует. Можно его добавить или вернуться и выбрать другое<br>';
    //  tablename="raspred";
    //  runame="Распределение";
    // myAlert (varHTML, tablename, runame);
  }
  else if($('#typeId').val() == '')
  {
    alert("Выберите тип");
    // varHTML='Значение отсутствует. Можно его добавить или вернуться и выбрать другое<br>';
    //  tablename="type";
    //  runame="Тип связи";
    // myAlert (varHTML, tablename, runame);  
  }
  else if($('#subId').val() == ''){
    alert("Выберите абонента. Если необходимое имя абонента отсутствует, добавте его через меню БД-->Абоненты");
  }
  else
  { 
    $.ajax({
      url: 'dataexecute.php',
      method:"POST",
      data:$('#dataCrudForm').serialize(),
      success: function(data) {
        $('#container_p').html(data);
        $('#dataCrudModal').modal('hide');
      }
    });}
  }

// Проверка на наличие номера// Данных
// checkData
$(document).on('keyup', '#dataKross', function(){
 var area=("param_area", param_area.value);
 if($(this).val().length>=3)
 {
  $.ajax({
   url:"dataautosearch.php",
   method:"POST",
   data:$('#dataCrudForm').serialize(),
   success:function(data)
   {
    $('#dataList').fadeIn();
    $('#dataList').html(data);
  }
});
}else{
  $('#dataList').html("");
}
});

$(document).on('keyup', '#dataNumber', function(){
  var area=("param_area", param_area.value);
  if($(this).val().length==4 || $(this).val().length==7)
  {
    var querynumber = $(this).val();
    $.ajax({
     url:"dataautosearch.php",
     method:"POST",
     data:{querynumber:querynumber, area:area},
     success:function(data)
     {
      $('#numberList').fadeIn();
      $('#numberList').html(data);
    }
  });
  } else{
    $('#numberList').html($(this).val().length);
  }
});
// обработка таблицы krossdata END




$(document).on('click', '.autoClear', function(){
  $('#result').remove();
});

$(document).on('click', '.autoListData', function(){
  var idinput=event.target.id;
  var tablename = event.target.dataset.table;
  var query = $(this).val();
  var columnname=tablename+"_name";
  idinput='#'+idinput;
  $('#result').remove();
  autoListData(tablename, idinput, query, columnname);
});


$(document).on('keyup', '.autoListData', function(){
  var idinput=event.target.id;
  var tablename = event.target.dataset.table;
  var query = $(this).val();
  var columnname=tablename+"_name";
  idinput='#'+idinput;
  autoListData(tablename, idinput, query, columnname);
});

function autoListData(tablename, idinput, query, columnname) {
  console.log("Какой инпут посылает запрос (событие onkeyup): ", idinput);
  console.log("Длинна запроса: ", query.length);
  console.log("Атрибут data-table после click: ", document.getElementById("staAutoList").getAttribute("data-table"));
  console.log("Поиск по таблице: ", tablename);
  console.log("Запрос: ", query);
  if(!$("div").is("#result")){
    $("<div id='result' style='height:300px;overflow-y:scroll;'></div>").insertAfter(idinput);
  }
  if((query.length)==0){
    console.log("Пустой запрос");
    //$('#idname').val('');
  }
  $.ajax({
   url:"loadfetch.php",
   method:"POST",
   data:{idinput:idinput, query:query, tablename:tablename, columnname:columnname},
   success:function(data)
   {
    $('#result').html(data);
    if ($("div").is("#alertInfo")){
    // alert('ssssssssssssssssssssssssssssss');
    var idvariable='#'+tablename+'Id';
    $(idvariable).val('');
  }
  if ($("div").is("#resultreturt")){
    // alert('ssssssssssssssssssssssssssssss');
    var idvariabl='#'+tablename+'Id';
    $(idvariabl).val('');
  }
}
});
}

$(document).on('click', '.tablecolumn', function(){
  var value=(this.getAttribute("data-value"));
  var input=(this.getAttribute("data-idinput"));
  var idname=(this.getAttribute("data-idname"));
  $(input).val(value);
  $('#idname').val(idname);

});


//Поиск по данным

//Передаем параметры поиска из формы запроса к БД
//area--Площадка
//searchString---Строка поиска
//paramPoisk--Параметры поиска (Данные, Распределение, Телефон, Имя, Тип, Комментарии)
function poisk(){
  var searchString=$('#searchString').val();
  var paramPoisk =$('#paramPoisk').val();
  $.ajax({
    url:"poisk_select.php",
    method:"POST",
    data:{searchString:searchString, paramPoisk:paramPoisk},
    dataType:"text",
    success:function(data){
      $('#container_p').html(data);
    }
  });
}

$("form_poisk").on("submit", function(){
  // alert("submit");
  poisk();
  return false;
});
$(document).on('click', '#select_poisk', function(){
// $(document).on('click', '#searchString', function(){
// alert("select_poisk");
  poisk();
  return false;
});
//DATA-NUMBER подгрузка из справочника???
$(document).on('click', '.data-number', function(){
  var searchString=$(this).data("idnumber");
  var paramPoisk ="number";
  $.ajax({
    url:"poisk_select.php",
    method:"POST",
    data:{searchString:searchString, paramPoisk:paramPoisk},
    dataType:"text",
    success:function(data){
      $('#container_p').html(data);
    }
  });
});
//DATA-NUMBER END




/////////////////////////////Каталог///////////////////////////
//Редактор справочника
function catalogEdit(page)
{ 
  // $('#spr2').hide();
  // $('#spr').show();
  header='<nav class="navbar navbar-default">\
  <div class="container-fluid">\
  <div class="navbar-header">\
  <a href="#" data-www="redaktorCatalog" onclick="catalogEdit(1)" class="headerPage"><h4>Редактор справочника</h4></a>\
  </div>\
  <ul class="nav navbar-nav navbar-right">\
  <li><a href="#" name="catalog_red" id="catalog_red" data-toggle="modal" onclick="catalogAdd()">Добавить абонента</a></li>\
  <li><a href="#" onclick="messageRead()">Обратная связь</a></li>\
  </ul>\
  </div>\
  </nav>';
  $.ajax({
    url:"catalogedit.php",
    method:"POST",
    data:{page:page},
    success:function(data){
     $('#container_p').html(data);
                     //$('#poisk').load('catalog_form.php');
                     //$('#message').load('read_message.php');
                     //messageRead();
                     $('#top_header_left').html(header);

                   }
                 });

  $.ajax({
    url: 'catalog_search_form.php',
    success: function(data) {
      $('#poisk').html(data);
    }
  });

}


//Открыть справочник
function catalogOpen()
{ 
  window.open("/catalog/catalog.php");
}

// Поиск по справочнику
function poisk_spr(){
  var searchString =$("#searchString").val();
  var paramPoisk =("paramPoisk", formPoiskCatalog.paramPoisk.value);
  $.ajax({
   url:"catalog_select_red.php",
   method:"POST",
   data:{searchString:searchString, paramPoisk:paramPoisk},
   dataType:"text",
   success:function(data){
    $('#container_p').html(data);
  }
});
}

$("formPoiskCatalog").on("submit", function(){
  poisk_spr();
  return false;
});
$(document).on('click', '#poiskCatalog', function(){
  poisk_spr();
  return false;
});

//Редактировать абонента в СПРАВОЧНИКЕ
$(document).on('click', '.red_modal', function(){
  $('#catalog_red_form')[0].reset();
  $('#result').remove();
  document.getElementById('insert_update').innerHTML="Изменить";
  var subname=$(this).data("sub");
  document.getElementById('modal_title_catalog').innerHTML="Редактировать абонента:<br>"+subname;
  var data_id = $(this).data("id");
  var subid=$(this).data("subid");
  $('#subidred').val(subid);
  $('#login_idred').val($('#login').text());
          //$('#subidupdate').val("");
          $('#subIdUpdate').val(subid);
          $.ajax({
            url:"catalog_fetch_red.php",
            method:"POST",
            data:{data_id:data_id},
            dataType:"json",
            success:function(data){
             //$('#catalogId').val(data.id);
             $('#catalogId').val(data.id);
             $('#catalogSub').val(data.sub_name);
             $('#catalogVnutr').val(data.vnutr);
             $('#catalogCity').val(data.city);
             $('#catalogUnit').val(data.unit_name);
             $('#catalogDepartment').val(data.department_name);
             $('#catalogCabinet').val(data.cabinet);
             $('#catalogFilial').val(data.filial_name);
             $('#catalogVisibility').val(data.visibility);
             // $('#login_idred').val($('#login').text());
             $('#catalogUnitidname').val(data.unit_id);

             $('#data_departmentidname').val(data.department_id);

             $('#data_filialidname').val(data.filial_id);

             $('#catalog_red_Modal').modal('show');
             console.log ("catalog_red_Modal", "ok");

           }
         });
        });

//Добавить нового абонента в справочник
function catalogAdd() {

  $('#catalog_red_form')[0].reset();
  // if ($('div').is('#result')){
    $('#result').remove();
    $('#login_idred').val($('#login').text());
// }

document.getElementById('insert_update').innerHTML="Добавить абонента";
document.getElementById('modal_title_catalog').innerHTML="Добавить абонента";
$('#catalog_red_Modal').modal('show');
}

$(document).on('click', '.catalogNumberAdd', function(){
  $('#catalog_red_form')[0].reset();
  $('#result').remove();
  $('#catalogVnutr').val($(this).data("number"));
  $('#catalogSub').val($(this).data("sub"));
  // var data_id = $(this).data("id");
  $('#login_idred').val($('#login').text());
  document.getElementById('insert_update').innerHTML="Добавить абонента";
  document.getElementById('modal_title_catalog').innerHTML="Добавить абонента";
  $('#catalog_red_Modal').modal('show');
});
function catalogCRUD() {
  // body...
  event.preventDefault();
  if($('#catalogSub').val() == "")
  {
    alert("Введите имя абонента");
  }
//             else if (($('#catalogVisibility').val() != "1" ) || ($('#catalogVisibility').val() != "0" ))
// {
//               alert("Задайте видимость абонента в каталоге");
//            }
else
{

  $.ajax({
   url:"catalog_update.php",
   method:"POST",
   data:$('#catalog_red_form').serialize(),
   success:function(data){
     $('#catalog_red_form')[0].reset();
     $('#catalog_red_Modal').modal('hide');
     $('#container_p').html(data);
   }
 });
}
}



/////////////////////ЧИТАЕМ ЛОГИ
function readLogData(page)
{ 
  // $('#spr2').hide();
  // $('#spr').show();
  header='<nav class="navbar navbar-default">\
  <div class="container-fluid">\
  <div class="navbar-header">\
  <a href="#" data-www="logKross" class="headerPage"><h4>Лог Кросса</h4></a>\
  </div>\
  </div>\
  </nav>';
  poiskLog='<div class="form-group">\
  <div class="input-group">\
  <span class="input-group-addon">Поиск</span>\
  <input type="text" name="search_text" id="search_text" placeholder="Поиск по логу кроссового журнала" class="form-control" />\
  </div>\
  </div>';
  $.ajax({
    url:"logkross.php",
    method:"POST",
    data:{page:page},
    success:function(data){
     $('#container_p').html(data);

     $('#top_header_left').html(header);
     $('#poisk').html(poiskLog);
   }
 });



}
function readLogCatalog(page)
{ 
  // $('#spr2').hide();
  // $('#spr').show();
  header='<nav class="navbar navbar-default">\
  <div class="container-fluid">\
  <div class="navbar-header">\
  <a href="#" data-www="logCatalog" class="headerPage"><h4>Лог Справочника</h4></a>\
  </div>\
  </div>\
  </nav>';
  poiskLog='<div class="form-group">\
  <div class="input-group">\
  <span class="input-group-addon">Поиск</span>\
  <input type="text" name="search_text" id="search_text" placeholder="Поиск по логу справочника" class="form-control" />\
  </div>\
  </div>';
  $.ajax({
    url:"logcatalog.php",
    method:"POST",
    data:{page:page},
    success:function(data){
     $('#container_p').html(data);

     $('#top_header_left').html(header);
     $('#poisk').html(poiskLog);
   }
 });



}


/////////////////////ЧИТАЕМ ЛОГИ END
////Поиск текста на странице при помощи Jquery
$(document).on('keyup change', '#search_text', function(){
    // $('#search_text').bind('keyup change', function(ev) {
        // вставка нового искомого значения
        var searchTerm = $(this).val();

        // удаление любого старого подсвеченного значения
        $('#container_p').removeHighlight();
        // отключить подсвечивание, если переменная поиска пуста
        if ( searchTerm ) {
            // подсветить, если введено новое слово или значение
            $('#container_p').highlight( searchTerm );
          }
    // });
});////Поиск текста на странице при помощи Jquery

//////////////Заявки
function readBid(page) {
  // body...
  // $('#spr2').hide();
  // $('#spr').show();
  header='<nav class="navbar navbar-default">\
  <div class="container-fluid">\
  <div class="navbar-header">\
  <a href="#" data-www="bid" class="headerPage"><h4>Заявки</h4></a></div></div></nav>';
  poiskbid='<div class="form-group"><div class="input-group"><span class="input-group-addon">Поиск</span><input type="text" name="search_text" id="search_text" placeholder="Поиск заявки" class="form-control" /></div></div>';
  $.ajax({
    url:"bidselect.php",
    cache: false,
    method:"POST",
    data:{page:page},
    success:function(data){
     $('#container_p').html(data);

     $('#top_header_left').html(header);
     $('#poisk').html(poiskbid);
     // func();
   }
 });
}

function stateBid(idbid) {
 $.ajax({
  url: "readBidModal.php",
  cache: false,
  success: function(html){
    $("body").append(html);
  }
});
 $.ajax({
  url: "stateBid.php",
  method:"POST",
  data:{idbid:idbid},
  dataType:"json",
  success: function(data){
    $('#stateidbid').val(data.id);
    $('#phone').val(data.phone);
    $('#bidMessage').val(data.bidmessage);
    $('#phoneObr').val(data.phoneobr);
    $('#statebid').val(data.state);
    $('#commentbid').val(data.commentbid);
    $('#titleReadBid').html('Заявка № : '+data.id+'. Зарегестрирована '+data.datemessage);
    $('#readBidModal').modal('show');
  }
});
}
function updateStateBid() {
  stateidbid=$('#stateidbid').val();
  state=$('#statebid').val();
  commentbid=$('#commentbid').val();
  $.ajax({
    url: "stateBid.php",
    method:"POST",
    data:{stateidbid:stateidbid, state:state, commentbid:commentbid},
    dataType:"json",
    success: function(data){
      // $('#idbid').val(data.id);
      // $('#phone').val(data.phone);
      // $('#bidMessage').val(data.bidmessage);
      // $('#phoneObr').val(data.phoneobr);
      // $('#statebid').val(data.state);
      // $('#commentbid').val(data.commentbid);
      // $('#titleReadBid').html('Заявка № : '+data.id+'. Зарегестрирована '+data.datemessage+'</br>Текущий статус обновлен : '+data.commentbid);
      $('#readBidModal').modal('hide');
      console.log("readBidModal---hide");
      // $('#readBidModal').remove();
      readBid(1);
    }
  });

}

//////////////Заявки END
//Обработка сообщений обратной связи
//

function messageRead(){
  $.ajax({
                     url:"read_message.php",
                     method:"POST",
                     dataType:"text",
                     success:function(data){
                          //$("#top_content_right").empty();
                          // $('<div id="message_area"></div>').insertBefore('#container_p');
                          // var button='<button type="button" class="btn" onclick="closeMessageArea()">Basic</button>';
                          // data=button+data;
                          // $('#message_area').html(data);
                          $('#container_p').html(data);

                     }
                });
}
function closeMessageArea() {
  $('#message_area').remove();
}

$(document).on('click', '.select_message', function(){
            var searchString =$(this).data("id_catalog");
console.log(searchString+'id абонента в каталоге');
// alert(searchString+'id абонента в каталоге');
var id_message =$(this).data("id_message");///?????
console.log(id_message+'id запроса');
          var paramPoisk ="id";

                          $.ajax({
                     url:"select_message.php",
                     method:"POST",
                     dataType:"text",
                     data:{id_message:id_message},
                     success:function(data){
                          //$('#message').load("");
                          $('#container_p').html(data);
//                           var ip = document.getElementById("ip_message").innerHTML;
// var date = document.getElementById("date_message").innerHTML;
// document.getElementById("spr").innerHTML="IP"+ip+" Дата заявки "+date;

                     }
                });

                $.ajax({
                     url:"catalog_select_red.php",
                     method:"POST",
                     dataType:"text",
                     data:{searchString:searchString, paramPoisk:paramPoisk},
                     success:function(data){
                      var message=$('#container_p').html();
                      data=message+data;
                          $('#container_p').html(data);
                          // document.getElementById('table_catalog_select').innerHTML="Текущие данные по каталогу";
                     }
                });
                // var data =$(this).data("id_message");///?????

          });


$(document).on('click', '.btn_obr', function(){
           var data=$(this).data("id");
           if(confirm("Исправления внесены?"))
           {
                $.ajax({
                     url:"status_message.php",
                     method:"POST",
                     data:{data:data},
                     dataType:"text",
                     success:function(data){
                          alert(data);
                          $('#container_p').load('read_message.php');
                                               // $('#container_p').html("");
                                               // $('#spr').html("");
                    // $('#message').html("");
                          //fetch_data(1);
                     }
                });
           }
      });
//Обработка сообщений обратной связи END

function stats() {
  $.ajax({
      url: "show_allstats.php",
      cache: false,
      success: function(html){
        $("#container_p").html(html);
      }
    });
}