<?php
require 'connect.php'; // подключаем скрипт
$data=$_POST;
$tablename = $_POST["tablename"];
$idname = $_POST["idname"];
switch ($tablename) {
	case 'unit':
		R::exec("UPDATE catalog SET   catalog.unit_id =1 WHERE catalog.unit_id=$idname");
	break;
	case 'department':
		R::exec("UPDATE catalog SET   catalog.department_id =1 WHERE catalog.department_id=$idname");
	break;
	case 'filial':
		R::exec("UPDATE catalog SET   catalog.filial_id =1 WHERE catalog.filial_id=$idname");
	break;
	case 'rasperd':
		R::exec("UPDATE krossdata SET   krossdata.rasperd_id =1 WHERE krossdata.rasperd_id=$idname");
	break;
	case 'sub':
		R::exec("UPDATE catalog SET   catalog.sub_id =1 WHERE catalog.sub_id=$idname");
		R::exec("UPDATE krossdata SET   krossdata.sub_id =1 WHERE krossdata.sub_id=$idname");
	break;
	case 'type':
		R::exec("UPDATE krossdata SET   krossdata.type_id =1 WHERE krossdata.type_id=$idname");
	break;
	case 'area':
		R::exec("UPDATE krossdata SET   krossdata.area_id =1 WHERE krossdata.area_id=$idname");
	break;
	
	default:
		# code...
	break;
}
$beean=R::load($tablename, $idname);
R::trash($beean);
echo "Инфомация удалена";

?>