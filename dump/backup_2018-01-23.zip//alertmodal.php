<div class="modal fade" id="myAlert">
    <div class="modal-dialog modal-lg" style='position: relative; width: 95%; margin: 10px;'>
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Предупреждение</h4>
        </div>
        <div class="modal-body">
        	<div class="alert alert-danger" id="alertdialog"></div>
        	<!-- <button type="button" class="btn btn-default" data-dismiss="modal"><a href="#" onclick=" staCRUD('raspred', 'Распределение')"><span>Распределение</span></a></button> -->
          <!-- <p id="alertdialog">This is a small alert.</p> -->
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>