<?php
require 'connect.php';
 $output = '';

 $searchString=htmlspecialchars($_POST['searchString']);
  $paramPoisk=htmlspecialchars($_POST['paramPoisk']);
   //$area=htmlspecialchars($_POST['area']);
$length_number=strlen($searchString);

////Пробежимся по таблице площадок
$areaQuery = R::getAll('SELECT area_name FROM area');
  foreach($areaQuery as $row)
 {
$outp_red="<div class='table-responsive' id='outp_red'>";
echo($outp_red);
$output="";
$areaaaa=$row['area_name'];
switch ($paramPoisk) {
case "number":
$beans = R::getAll('SELECT krossdata.data, krossdata.raspred_id, raspred.raspred_name, krossdata.number, krossdata.sub_id, sub.sub_name, sub.id, type.type_name, krossdata.comment, area.area_name
FROM krossdata
INNER JOIN sub ON krossdata.sub_id = sub.id
INNER JOIN type ON krossdata.type_id = type.id
INNER JOIN area ON krossdata.area_id = area.id
INNER JOIN raspred ON krossdata.raspred_id = raspred.id
WHERE area.area_name=? AND  length(krossdata.number)=? 
AND ' .$paramPoisk.' LIKE ? ORDER BY raspred_id', [ $areaaaa, $length_number, '%' . $searchString . '%' ]);
//var_dump($beans);
break;
default:

// $subId=R::getCol('select id from sub where sub_name=?', [$searchString]);
// $searchString=$subId[0];
$beans = R::getAll('SELECT krossdata.data, krossdata.raspred_id, raspred.raspred_name, krossdata.number, krossdata.sub_id, sub.sub_name, sub.id, type.type_name, krossdata.comment, area.area_name
FROM krossdata
INNER JOIN sub ON krossdata.sub_id = sub.id
INNER JOIN type ON krossdata.type_id = type.id
INNER JOIN area ON krossdata.area_id = area.id
INNER JOIN raspred ON krossdata.raspred_id = raspred.id
WHERE area.area_name=? AND ' .$paramPoisk.' LIKE ? ORDER BY number', [ $areaaaa, '%' . $searchString . '%' ]);
break;
}
/////

 $output .= '
      <div class="table-responsive" style="border-color:blue; border-style: double; margin-top: 5px; border-radius: 10px;">
           <table class="table table-bordered table-hover">
           <h3 style="color:blue">Информация по кроссу '.$areaaaa.'</h3>
           <thead>
                <tr>
                     <th>Данные</th>
                     <th>Распределение</th>
                     <th>Номер</th>
                     <th>Имя</th>
                     <th>Тип</th>
                     <th>Комментарии</th>
                     <th>Имя по Кроссам</th>
                     <th>Площадка</th>
                </tr>';
foreach($beans as $row)
 {
  switch ($row["type_name"]) {
          case 'Прямая':
            $color='class="w3-aqua"';
            break;
          case 'Сигнализация':
            $color='class="w3-blue"';
            break;
          case 'Часы':
            $color='class="w3-violet"';
            break;
          case 'Телефон':
            $color='class="w3-lime2"';
            break;
          case 'Земля':
            $color='class="w3-olive"';
            break;
          case 'Обрыв':
            $color='class="w3-red"';
            break;
            case 'Свободный':
            $color='class="w3-yellow"';
            break;
          case 'Сирена':
            $color='class="w3-navy"';
            break;
          default:
            $color='';
            break;
          }
          $output .= '
                <tr '.$color.'>
                     <td  class="edit_data"  data-subid="'.$row["sub_id"].'" data-idxxx="'.$row["data"].'" data-idarea="'.$row["area_name"].'" title="Редактировать?" id="tdselect"><b>'.$row["data"].' </b><span class="glyphicon glyphicon-edit"></span></td>
                     <td data-f="'.$row["data"].'" >'.$row["raspred_name"].'</td>
                     <td class="data-number" data-number="'.$row["data"].'" data-idnumber="'.$row["number"].'">'.$row["number"].' <span class="glyphicon glyphicon-search"></span></td>
                     <td data-sub="'.$row["sub_name"].'" data-name="'.$row["data"].'" >'.$row["sub_name"].'</td>
                     <td data-type="'.$row["data"].'" >'.$row["type_name"].'</td>
                     <td data-comment="'.$row["data"].'" >'.$row["comment"].'</td>
                     <td data-comment="'.$row["data"].'" >'.$row["name_xxx"].'</td>
                     <td data-comment="'.$row["data"].'" >'.$row["area_name"].'</td>
                </tr>
                ';
        }
 
// if ($beans==null){$output=''; $output='<br><div class="alert alert-info">
//   <strong>'.$areaaaa.'</strong> данные не найдены.
// </div>';}
        if ($beans==null){$output=''; $output='<br>';}
 echo $output.='</tbody> </table></div>';

 }//по таблице площадок

////////////TTTT


                /////////////////////
                //ПРоверка наличия номера в каталоге
$output='';
      switch ($paramPoisk) {
    case "number":
$strlong=strlen($searchString);
// switch ($strlong) {
//   case '4':
$catalogBeans=R::getAll('SELECT catalog.id, catalog.sub_id, sub.sub_name, catalog.vnutr, catalog.city, unit.unit_name, department.department_name, catalog.cabinet, filial.filial_name, catalog.visibility
FROM catalog
INNER JOIN sub ON catalog.sub_id = sub.id
INNER JOIN unit ON catalog.unit_id = unit.id
INNER JOIN department ON catalog.department_id = department.id
INNER JOIN filial ON catalog.filial_id = filial.id
WHERE vnutr LIKE ? AND length(catalog.vnutr)=?
ORDER BY catalog.id', ['%' . $searchString . '%', $length_number]);
  $output .= '
  <div class="table-responsive" id="catalog_table" style="border-color:blue; border-style: double; margin-top: 5px;">
            <table class="table table-bordered table-hover">
             <h3>Информация в справочнике</h3>
                <tr><thead>
                     <th>ID</th>
                     <th>Абонент</th>
                     <th>Внутренний</th>
                     <th>Городской</th>
                     <th>Управление</th>
                     <th>Отдел/Бюро</th>
                     <th>Филиал</th>
                </tr></thead>';
  foreach($catalogBeans as $row)
 {
if (($row["visibility"])=="1"){
 $output .= '
               <tbody> <tr>
                     <td class="red_modal" data-sub="'.$row["sub_name"].'" data-id="'.$row["id"].'" data-subid="'.$row["sub_id"].'">'.$row["id"].'<span class="glyphicon glyphicon-edit"></span></td>
                     <!--td  class="feedback" data-id="'.$row["id"].'" style="background:  #CDC5BF">'.$row["sub"].'</td-->
                     <td data-sub="'.$row["sub_name"].'" data-subid="'.$row["sub_id"].'" data-catalogid="'.$row["id"].'">'.$row["sub_name"].'</td>
                     <td class="data-number" data-idnumber="'.$row["vnutr"].'">'.$row["vnutr"].'</td>
                     <td>'.$row["city"].'</td>
                     <td>'.$row["unit_name"].'</td>
                     <td>'.$row["department_name"].'</td>
                     <td>'.$row["filial_name"].'</td>

                </tr>
           ';
         } else {
          $output .= '
               <tbody> <tr style="background:  #FF4500";>
                     <td class="red_modal  edit_data" data-sub="'.$row["sub_name"].'" data-id="'.$row["id"].'" data-subid="'.$row["sub_id"].'">'.$row["id"].'<span class="glyphicon glyphicon-edit"></span></td>
                     <!--td  class="feedback" data-id="'.$row["id"].'" style="background:  #CDC5BF">'.$row["sub"].'</td-->
                     <td data-sub="'.$row["sub_name"].'" data-subid="'.$row["sub_id"].'" data-catalogid="'.$row["id"].'">'.$row["sub_name"].'</td>
                     <td class="data-number" data-idnumber="'.$row["vnutr"].'">'.$row["vnutr"].'</td>
                     <td>'.$row["city"].'</td>
                     <td>'.$row["unit_name"].'</td>
                     <td>'.$row["department_name"].'</td>
                     <td>'.$row["filial_name"].'</td>

                </tr>
           ';
         }
   }
   $output .= '</tbody> </table></div>';
if ($catalogBeans==null){$output=''; $output='<br><div class="alert alert-danger">
  Номер : <strong>'.$searchString.'</strong><br> Отсутствует в справочнике</div>';}
echo $output;
break;


case "sub_name":
$catalogBeans=R::getAll('SELECT catalog.id, catalog.sub_id, sub.sub_name, catalog.vnutr, catalog.city, unit.unit_name, department.department_name, catalog.cabinet, filial.filial_name, catalog.visibility
FROM catalog
INNER JOIN sub ON catalog.sub_id = sub.id
INNER JOIN unit ON catalog.unit_id = unit.id
INNER JOIN department ON catalog.department_id = department.id
INNER JOIN filial ON catalog.filial_id = filial.id
WHERE sub.sub_name LIKE ? ORDER BY catalog.id', ['%' . $searchString . '%']);
  $output .= '
  <div class="table-responsive" id="catalog_table">
            <table class="table table-bordered table-hover">
             <h3>Информация в справочнике</h3>
                <tr><thead>
                     <th>ID</th>
                     <th>Абонент</th>
                     <th>Внутренний</th>
                     <th>Городской</th>
                     <th>Управление</th>
                     <th>Отдел/Бюро</th>
                     <th>Филиал</th>

                </tr></thead>';
                foreach($catalogBeans as $row)
 {
 $output .= '
               <tbody> <tr>
                     <td class="red_modal" data-sub="'.$row["sub_name"].'" data-id="'.$row["id"].'" data-subid="'.$row["sub_id"].'">'.$row["id"].'</td>
                     <!--td  class="feedback" data-id="'.$row["id"].'" style="background:  #CDC5BF">'.$row["sub"].'</td-->
                     <td data-sub="'.$row["sub_name"].'" data-subid="'.$row["sub_id"].'" data-catalogid="'.$row["id"].'">'.$row["sub_name"].'</td>
                     <td>'.$row["vnutr"].'</td>
                     <td>'.$row["city"].'</td>
                     <td>'.$row["unit_name"].'</td>
                     <td>'.$row["department_name"].'</td>
                     <td>'.$row["filial_name"].'</td>


                </tr>
           ';
   }
   $output .= '</tbody> </table></div>';
if ($catalogBeans==null){$output=''; $output='<br><div class="alert alert-danger">
  <strong>Имя : '.$searchString.'<br> Отсутствует в справочнике</strong></div>';}
echo $output;
break;
}
?>