<?php
require 'connect.php'; // подключаем скрипт
$data=$_POST;
$errors=array();
$output = '';
$message = '';
$dataKross=$_POST['dataKross'];
$dataRaspred=$_POST['dataRaspred'];
$dataNumber=$_POST['dataNumber'];
$dataSub=$_POST['dataSub'];
$previousSubId=$_POST['previousSubId'];
$dataType=$_POST['dataType'];
$dataComment=$_POST['dataComment'];
$areaName=$_POST['areaName'];
$loginName=$_POST['loginName'];
$dataId=$_POST['dataId'];

$raspredId=$_POST['raspredId'];
$subId=$_POST['subId'];
$typeId=$_POST['typeId'];
$areaId=$_POST['areaId'];

$message.='<br><label class="text-success">Результат обработки</label>';

// $subId=R::getCol('select id from sub where sub_name=?', [$data["dataSub"]]);

// if (empty($subId)){
//   $sub=R::dispense('sub');
//   $sub->sub_name=$data["dataSub"];
//   R::store($sub);
//   $subId=R::getCol('select id from sub where sub_name=?', [$data["dataSub"]]);
//   // $subId=$subId[0];
//   $message.= '<div class="alert alert-info" role="alert">Имя абонента : '.'<strong style="color: red">'.$data["dataSub"].'</strong>'.' Отсутствовало в базе, но было добавлено </div>';
// }

// $raspredId=R::getCol('select id from raspred where raspred_name=?', [$data["dataRaspred"]]);

// if (empty($raspredId)){
//   $raspred=R::dispense('raspred');
//   $raspred->raspred_name=$data["dataRaspred"];
//   R::store($raspred);
//   $raspredId=R::getCol('select id from raspred where raspred_name=?', [$data["dataRaspred"]]);
//   // $raspredId=$raspredId[0];
//   $message.= '<div class="alert alert-info" role="alert">Значение распределения : '.'<strong style="color: red">'.$data["dataRaspred"].'</strong>'.' Отсутствовало в базе, но было добавлено </div>';
// }

// $typeId=R::getCol('select id from type where type_name=?', [$data["dataType"]]);

// if (empty($typeId)){
//   $type=R::dispense('type');
//   $type->type_name=$data["dataType"];
//   R::store($type);
//   $typeId=R::getCol('select id from type where type_name=?', [$data["dataType"]]);
//   // $typeId=$typeId[0];
//   $message.= '<div class="alert alert-info" role="alert">Значение типа : '.'<strong style="color: red">'.$data["dataType"].'</strong>'.' Отсутствовало в базе, но было добавлено </div>';
// }

// $areaId=R::getCol('select id from area where area_name=?', [$areaName]);

if (empty($dataId)) {
	$data=R::dispense('krossdata');
	$data->data=$dataKross;
	$data->number=$dataNumber;
	$data->comment=$dataComment;
	$data->raspred=R::load('raspred', $raspredId);
	$data->sub=R::load('sub', $subId);
	$data->type=R::load('type', $typeId);
	$data->area=R::load('area', $areaId);
	R::store($data);
  $getinsertID=R::getinsertID();
	$message.= '<div class="alert alert-info" role="alert">Добавлены новые данные: '.$dataKross.'</div>';
  // R::exec( "SET @user_login='$loginName', @operation='Новая запись'");
  $logkross=R::dispense('logkross');
  $logkross->data_id=$getinsertID;
  $logkross->data_name=$dataKross;
  $logkross->raspred=$dataRaspred;
  $logkross->number=$dataNumber;
  $logkross->sub=$dataSub;
  $logkross->type=$dataType;
  $logkross->comment=$dataComment;
  $logkross->area=$areaName;
  $logkross->user=$loginName;
  $logkross->operation="Новая запись";
  R::store($logkross);
	// $output = 'Добавляем';
	// echo($output);
} else {
	$data = R::load( 'krossdata', $dataId ); //reloads our data
  $logkross=R::dispense('logkross');
  $logkross->data_id=$data->id;
  $logkross->data_name=$data->data;
  $logkross->raspred=$data->raspred['raspred_name'];
  $logkross->number=$data->number;
  $logkross->sub=$data->sub['sub_name'];
  $logkross->type=$data->type['type_name'];
  $logkross->comment=$data->comment;
  $logkross->area=$areaName;
  $logkross->user=$loginName;
  $logkross->operation="Даннные до изменения";
  R::store($logkross);
	$data->number=$dataNumber;
	$data->comment=$dataComment;
	$data->raspred=R::load('raspred', $raspredId);
	$data->sub=R::load('sub', $subId);
	$data->type=R::load('type', $typeId);
  $dart=$data->type;
	$data->area=R::load('area', $areaId);
	R::store($data);
  $data = R::load( 'krossdata', $dataId ); //reloads our data
  $logkross=R::dispense('logkross');
  $logkross->data_id=$data->id;
  $logkross->data_name=$data->data;
  $logkross->raspred=$data->raspred['raspred_name'];
  $logkross->number=$data->number;
  $logkross->sub=$data->sub['sub_name'];
  $logkross->type=$data->type['type_name'];
  $logkross->comment=$dataComment;
  $logkross->area=$areaName;
  $logkross->user=$loginName;
  $logkross->operation="Даннные после изменения";
  R::store($logkross);
  // R::exec( "SET @user_login='$loginName', @operation='Данные обновлены'");
	$message.= '<div class="alert alert-info" role="alert">Данные : <strong>'.$dataKross.'</strong> обновлены</div>';
  if ($subId != $previousSubId) {
  // R::exec("UPDATE krossdata SET   krossdata.sub_id = $subId WHERE krossdata.number='".$dataNumber."' AND krossdata.sub_id = $previousSubId");
    $idDataKross=R::getCol('SELECT id FROM krossdata WHERE krossdata.number=? AND krossdata.sub_id=?', [$dataNumber, $previousSubId]);
    foreach ($idDataKross as $row) {
      $data = R::load( 'krossdata', $row ); //reloads our data
  $logkross=R::dispense('logkross');
  $logkross->data_id=$data->id;
  $logkross->data_name=$data->data;
  $logkross->raspred=$data->raspred['raspred_name'];
  $logkross->number=$data->number;
  $logkross->sub=$data->sub['sub_name'];
  $logkross->type=$data->type['type_name'];
  $logkross->comment=$data->comment;
  $logkross->area=$data->area['area_name'];
  $logkross->user=$loginName;
  $logkross->operation="Даннные до изменения";
  R::store($logkross);
  $data->sub=R::load('sub', $subId);
  R::store($data);
  $data = R::load( 'krossdata', $row ); //reloads our data
  $logkross=R::dispense('logkross');
  $logkross->data_id=$data->id;
  $logkross->data_name=$data->data;
  $logkross->raspred=$data->raspred['raspred_name'];
  $logkross->number=$data->number;
  $logkross->sub=$data->sub['sub_name'];
  $logkross->type=$data->type['type_name'];
  $logkross->comment=$dataComment;
  $logkross->area=$areaName;
  $logkross->user=$loginName;
  $logkross->operation="Даннные после изменения";
  R::store($logkross);
      # code...
    }
 }
	// $output = 'Обновление';
	// echo($output);
}

echo($message);

$idDataKross=R::getCol('SELECT id FROM krossdata WHERE data=? AND area_id=?', [$dataKross, $areaId]);
	$updateDataKross=R::getAll('SELECT krossdata.id, krossdata.data, krossdata.raspred_id, raspred.raspred_name, krossdata.number, krossdata.sub_id, sub.sub_name, sub.id, type.type_name, krossdata.comment, area.area_name
FROM krossdata
INNER JOIN sub ON krossdata.sub_id = sub.id
INNER JOIN type ON krossdata.type_id = type.id
INNER JOIN area ON krossdata.area_id = area.id
INNER JOIN raspred ON krossdata.raspred_id = raspred.id
WHERE  krossdata.sub_id =? AND krossdata.number=?', [ $subId, $dataNumber ]);
$outputUpdate='';
	//echo($updateDataKross);
$outputUpdate .= '
      <div class="table-responsive" style="border-color:blue; border-style: double; margin-top: 5px; border-radius: 10px;">
           <table class="table table-bordered table-hover">
           <h3 style="color:blue">Обновленные данные</h3>
           <thead>
                <tr>
                     <th>Данные</th>
                     <th>Распределение</th>
                     <th>Номер</th>
                     <th>Имя</th>
                     <th>Тип</th>
                     <th>Комментарии</th>
                     <th>Имя по Кроссам</th>
                     <th>Площадка</th>
                </tr>';
	foreach($updateDataKross as $row){
		
		//$outputUpdate='<br>'.$row['number'];
		  switch ($row["type_name"]) {
          case 'Прямая':
            $color='class="w3-aqua"';
            break;
          case 'Сигнализация':
            $color='class="w3-blue"';
            break;
          case 'Часы':
            $color='class="w3-violet"';
            break;
          case 'Телефон':
            $color='class="w3-lime2"';
            break;
          case 'Земля':
            $color='class="w3-olive"';
            break;
          case 'Обрыв':
            $color='class="w3-red"';
            break;
            case 'Свободный':
            $color='class="w3-yellow"';
            break;
          case 'Сирена':
            $color='class="w3-navy"';
            break;
          default:
            $color='';
            break;
          }
          $outputUpdate .= '
                <tr '.$color.'>
                     <td  class="edit_data"  data-subid="'.$row["sub_id"].'" data-idxxx="'.$row["data"].'" data-idarea="'.$row["area_name"].'" title="Редактировать?"><b>'.$row["data"].' </b><span class="glyphicon glyphicon-edit"></span></td>
                     <td data-f="'.$row["data"].'" >'.$row["raspred_name"].'</td>
                     <td class="data-number" data-number="'.$row["data"].'" data-idnumber="'.$row["number"].'">'.$row["number"].' <span class="glyphicon glyphicon-search"></span></td>
                     <td data-sub="'.$row["sub_name"].'" data-name="'.$row["data"].'" >'.$row["sub_name"].'</td>
                     <td data-type="'.$row["data"].'" >'.$row["type_name"].'</td>
                     <td data-comment="'.$row["data"].'" >'.$row["comment"].'</td>
                     <td data-comment="'.$row["data"].'" >'.$row["name_xxx"].'</td>
                     <td data-comment="'.$row["data"].'" >'.$row["area_name"].'</td>
                </tr>
                ';
	}
	$outputUpdate.='</tbody> </table></div>';
	echo($outputUpdate);


//Обновляем информацию по номеру в каталоге (ПРИ НАЛИЧИИ ТАКОГО НОМЕРА)
	$catalog = R::getAll('SELECT catalog.id, sub.sub_name, catalog.vnutr, catalog.city, unit.unit_name, department.department_name, catalog.cabinet, filial.filial_name, catalog.visibility
	FROM catalog
	INNER JOIN sub ON catalog.sub_id = sub.id
	INNER JOIN unit ON catalog.unit_id = unit.id
	INNER JOIN department ON catalog.department_id = department.id
	INNER JOIN filial ON catalog.filial_id = filial.id
	WHERE sub.id=? and catalog.vnutr=? ORDER BY catalog.id', [$previousSubId, $dataNumber]);
	// WHERE sub.sub_name=? and catalog.vnutr=? ORDER BY catalog.id', [$previousSub, $dataNumber]);
	$outputcatalog='';
	$outputcatalog='Обновление записей по справочнику';
	if ($catalog==null){$outputcatalog=''; $outputcatalog='<br><div class="alert alert-danger">
	Номер : <strong>'.$dataNumber.'</strong> привязаный к абоненту  отсутствует в справочнике</div>';}
  // Номер : <strong>'.$dataNumber.'</strong> привязаный к абоненту '.$previousSub.' отсутствует в справочнике</div>';}


  else{


	foreach($catalog as $row)
	{
 	//$prsubId=R::getCol('select id from sub where sub_name=?', [$dataSub]);
	$catalogselect=R::load('catalog', $row['id']);
  $logcatalog=R::dispense('logcatalog');
  $logcatalog->catalog_id=$row['id'];
  $logcatalog->sub=$catalogselect->sub['sub_name'];
  $logcatalog->vnutr=$catalogselect->vnutr;
  $logcatalog->city=$catalogselect->city;
  $logcatalog->unit=$catalogselect->unit['unit_name'];
  $logcatalog->department=$catalogselect->department['department_name'];
  $logcatalog->cabinet=$catalogselect->cabinet;
  $logcatalog->filial=$catalogselect->filial['filial_name'];
  $logcatalog->visibility=$catalogselect->visibility;
  // $logcatalog->number=$catalogselect->number;
  $logcatalog->user=$loginName;
  $logcatalog->operation='До Изменения имени через кроссовый журнал';
  R::store($logcatalog);
	// $catalogselect->number=$dataNumber;
	$catalogselect->sub=R::load('sub', $subId);
	R::store($catalogselect);
  $catalogselect=R::load('catalog', $row['id']);
  $logcatalog=R::dispense('logcatalog');
  $logcatalog->catalog_id=$row['id'];
  $logcatalog->sub=$catalogselect->sub['sub_name'];
  $logcatalog->vnutr=$catalogselect->vnutr;
  $logcatalog->city=$catalogselect->city;
  $logcatalog->unit=$catalogselect->unit['unit_name'];
  $logcatalog->department=$catalogselect->department['department_name'];
  $logcatalog->cabinet=$catalogselect->cabinet;
  $logcatalog->filial=$catalogselect->filial['filial_name'];
  $logcatalog->visibility=$catalogselect->visibility;
  // $logcatalog->number=$catalogselect->number;
  $logcatalog->user=$loginName;
  $logcatalog->operation='После Изменения имени через кроссовый журнал';
  R::store($logcatalog);
	// $outputcatalog.='<br>#'.$row['id'];
	$outputcatalog.='<div class="alert alert-info">Запись ID: <strong>#'.$row['id'].'</strong> обновлена в справочнике</div>';
	}
            $outputcatalog.= '
           <label class="text-success">Результат обработки</label>';
          $outputcatalog.= '
       <div class="table-responsive" style="border-color:blue; border-style: double; margin-top: 5px; border-radius: 10px; id="catalog_table">
           <table class="table table-bordered table-striped">
           <thead>
                <tr>
                     <th>ID</th>
                     <th>Абонент</th>
                     <th>Внутренний</th>
                     <!--th>Городской</th-->
                     <th>Управление</th>
                     <th>Отдел/Бюро</th>
                     <th>Кабинет</th>
                     <th>Филиал</th>
                </tr>  </thead>';

$catalog = R::getAll('SELECT catalog.id, catalog.sub_id, catalog.unit_id, catalog.department_id, catalog.filial_id, sub.sub_name, catalog.vnutr, catalog.city, unit.unit_name, department.department_name, catalog.cabinet, filial.filial_name, catalog.visibility
FROM catalog
INNER JOIN sub ON catalog.sub_id = sub.id
INNER JOIN unit ON catalog.unit_id = unit.id
INNER JOIN department ON catalog.department_id = department.id
INNER JOIN filial ON catalog.filial_id = filial.id
WHERE sub.id=? and catalog.vnutr=? ORDER BY catalog.id', [$subId, $dataNumber]);
          foreach($catalog as $row)
 {
            if (($row["visibility"])=="1"){
           $outputcatalog.= '
                <tbody><tr>
                     <td  class="red_modal edit_catalog" data-sub="'.$row["sub_name"].'" data-id="'.$row["id"].'" data-www="tooltip" data-subid="'.$row["sub_id"].'">'.$row["id"].'<span class="glyphicon glyphicon-edit"></span></td>
                     <td  data-sub="'.$row["sub_name"].'" data-subid="'.$row["sub_id"].'" data-catalogid="'.$row["id"].'">'.$row["sub_name"].'</td>
                     <td class="data-number" data-idnumber="'.$row["vnutr"].'">'.$row["vnutr"].'</td>
                     <!--td>'.$row["city"].'</td-->
                     <td>'.$row["unit_name"].'</td>
                     <td>'.$row["department_name"].'</td>
                     <td>'.$row["cabinet"].'</td>
                     <td>'.$row["filial_name"].'</td>

                </tr>
           ';
         }
         else{$outputcatalog.= '
                <tbody><tr style="background:  #FF4500;">
                     <td  class="red_modal edit_catalog" data-sub="'.$row["sub_name"].'" data-id="'.$row["id"].'" data-www="tooltip" data-subid="'.$row["sub_id"].'">'.$row["id"].'<span class="glyphicon glyphicon-edit"></span></td>
                     <td  data-sub="'.$row["sub_name"].'" data-subid="'.$row["sub_id"].'" data-catalogid="'.$row["id"].'">'.$row["sub_name"].'</td>
                     <td class="data-number" data-idnumber="'.$row["vnutr"].'">'.$row["vnutr"].'</td>
                     <!--td>'.$row["city"].'</td-->
                     <td>'.$row["unit_name"].'</td>
                     <td>'.$row["department_name"].'</td>
                     <td>'.$row["cabinet"].'</td>
                     <td>'.$row["filial_name"].'</td>

                </tr>
           ';}

           }
           $outputcatalog.= '</table>';
    }
	echo($outputcatalog);
?>