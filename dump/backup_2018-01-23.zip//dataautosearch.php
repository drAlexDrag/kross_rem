<?php
require 'connect.php';
 if(isset($_POST["dataKross"]))
 {
      $output = '';
      $areaName =htmlspecialchars ($_POST["areaName"]);
      $dataKross =htmlspecialchars ($_POST["dataKross"]);
      $beans = R::getAll('SELECT krossdata.data, krossdata.raspred_id, krossdata.number, sub.sub_name, type.type_name, krossdata.comment, area.area_name, sub.id
FROM krossdata
INNER JOIN raspred ON krossdata.raspred_id=raspred.id
INNER JOIN sub ON krossdata.sub_id = sub.id
INNER JOIN type ON krossdata.type_id = type.id
INNER JOIN area ON krossdata.area_id = area.id
WHERE krossdata.data=? AND area.area_name=?', [ $dataKross, $areaName ]);

      $output = '<ul class="list-unstyled">';
      foreach($beans as $row)
      {
        if(strlen($row['number'])==0){
          $output .= '<li><div class="alert alert-success" role="alert">Данные '.$dataKross.' по '.$areaName.' пусты. Можно изменить в режиме редактирования</div></li>';
        }
       else{ $output .= '<li><div class="alert alert-success" role="alert">Данные '.$dataKross.' по '.$areaName.' привязаны к номеру '.$row['number'].'. <p style="color: red;">Необходимо указать другие данные или изменить '.$dataKross.' в режиме редактирования</p></div></li>';}

      }
      if ($beans==null) {
          $output .= '<li><div class="alert alert-success" role="alert">Данные '.$dataKross.' отсутствуют в базе '.$areaName.'</div></li>';
      }
      $output .= '</ul>';
      echo $output;
 }
  if(isset($_POST["querynumber"]))
 {
      $output = '';
      $dataNumber =htmlspecialchars ($_POST["querynumber"]);

$beans = R::getAll('SELECT krossdata.data, krossdata.raspred_id, raspred.raspred_name, krossdata.number, sub.id, sub.sub_name, type.type_name, krossdata.comment, area.area_name
FROM krossdata
INNER JOIN raspred ON krossdata.raspred_id=raspred.id
INNER JOIN sub ON krossdata.sub_id = sub.id
INNER JOIN type ON krossdata.type_id = type.id
INNER JOIN area ON krossdata.area_id = area.id
WHERE krossdata.number=? ORDER BY  raspred_id', [$dataNumber]);
      $output = '<ul class="list-unstyled">';

foreach($beans as $row){
  $output .= '<li><div class="alert alert-success col-sm-6" role="alert">Номер привязан к следующим данным '.$row['data'].'/Распределение '.$row['raspred_name'].'/'.$row['sub_name'].'/'.$row['area_name'].'</div></li>';
            }

     if ($beans==null){$output=''; $output .= '<li>Номер отсутствует в базе</li>';}
      $output .= '</ul>';
      echo $output;
 }
 ?>