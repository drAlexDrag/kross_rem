<div id="dataCrudModal" class="modal fade in" style="display: block; padding-right: 17px;">
  <div class="modal-dialog" style="position: relative; width: 95%; margin: 10px;">
   <div class="modal-content">
    <div class="modal-header">
     <button type="button" class="close" data-dismiss="modal">×</button>
     <h4 class="modal-title" id="dataCrudTitle">Редактируем данные №: 0000 кросса Транзистор</h4>
   </div>



   <div class="modal-body row">
     <div class="col-sm-10" style="
    border-right: 2px solid #ccc;
"><form method="post" id="dataCrudForm" class="form-horizontal">

       <div class="form-group">
        <label class="control-label col-sm-3">Данные:</label>
        <div class="col-sm-9">
          <input type="text" name="dataKross" id="dataKross" class="form-control verification autoClear" tabindex="1" data-original-title="" title="" readonly="readonly">
        </div>
        <div id="dataList"></div>
      </div>

      <div class="form-group">
       <label class="control-label col-sm-2">Распределение:</label>
       <div class="col-sm-10">
        <input type="text" name="dataRaspred" id="dataRaspred" data-table="raspred" data-input="#dataRaspred" class="form-control autoListData" tabindex="2" data-original-title="" title="">

        <!-- <div id="result"></div> -->
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-sm-3">Номер:</label>
      <div class="col-sm-9">
        <input type="text" name="dataNumber" id="dataNumber" class="form-control autoClear" tabindex="3" data-original-title="" title="">
      </div>
      <div id="numberList"></div>
    </div>

    <div class="form-group">
     <label class="control-label col-sm-3">Имя:</label>
     <div class="col-sm-9">
       <input type="text" name="dataSub" id="dataSub" data-table="sub" class="form-control autoListData" tabindex="4" data-original-title="" title="">
     </div>
   </div>

   <div class="form-group">
    <label class="control-label col-sm-3">Тип:</label>
    <div class="col-sm-9">
      <input type="text" name="dataType" id="dataType" data-table="type" class="form-control autoListData" tabindex="5" data-original-title="" title="">
    </div>
  </div>

  <div class="form-group">
    <label class="control-label col-sm-3">Комментарии:</label>
    <div class="col-sm-9">
      <input type="text" name="dataComment" id="dataComment" class="form-control autoClear" tabindex="6" data-original-title="" title="">
    </div>
  </div>

                    <input hidden="" type="text" name="previousSub" id="previousSub">
                    <input hidden="" type="text" name="areaName" id="areaName">
                    <input hidden="" type="text" name="dataId" id="dataId">
                    <input hidden="" type="text" name="subId" id="subId">
                    <input hidden="" type="text" name="loginName" id="loginName">
                    <input hidden="" class="id" type="text" name="raspredId" id="raspredId">
                    <input hidden="" class="id" type="text" name="typeId" id="typeId">
                    <input hidden="" type="text" name="areaId" id="areaId">
                    <!-- <input type='text' name='datasubupdate' id='datasubupdate' readonly/> -->
                    
</form></div>

                      <div class="col-sm-2"><button type="button" class="btn btn-success" onclick="dataExecute()" name="buttonDataExecute" id="buttonDataExecute">Обновить</button><br>
                    <button type="button" class="btn btn-danger" onclick="dataClear()" name="buttonDataClear" id="buttonDataClear">Очистить</button></div></div>


                      <div class="modal-footer">
                      <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                    </div>

</div></div></div>












<div id='dataCrudModal' class='modal fade'>
  <div class='modal-dialog' style='position: relative; width: 95%; margin: 10px;'>
   <div class='modal-content'>
    <div class='modal-header'>
     <button type='button' class='close' data-dismiss='modal'>&times;</button>
     <h4 class='modal-title' id='dataCrudTitle'></h4>
   </div>



   <div class='modal-body'>
     <form method='post' id='dataCrudForm'  class='form-horizontal'>

       <div class='form-group'>
        <label class="control-label col-sm-3">Данные:</label>
        <div class="col-sm-9">
          <input type='text' name='dataKross' id='dataKross' class='form-control verification autoClear' tabindex="1"/>
        </div>
        <div id='dataList'></div>
      </div>

      <div class='form-group'>
       <label class="control-label col-sm-3">Распределение:</label>
       <div class="col-sm-9">
        <input type='text' name='dataRaspred' id='dataRaspred' data-table="raspred" data-input="#dataRaspred" class='form-control autoListData' tabindex="2"/>

        <!-- <div id="result"></div> -->
      </div>
    </div>

    <div class='form-group'>
      <label class="control-label col-sm-3">Номер:</label>
      <div class="col-sm-9">
        <input type='text'  name='dataNumber' id='dataNumber' class='form-control autoClear' tabindex="3"/>
      </div>
      <div id='numberList'></div>
    </div>

    <div class='form-group'>
     <label class="control-label col-sm-3">Имя:</label>
     <div class="col-sm-9">
       <input type='text' name='dataSub' id='dataSub' data-table="sub" class='form-control autoListData' tabindex="4"/>
     </div>
   </div>

   <div class='form-group'>
    <label class="control-label col-sm-3">Тип:</label>
    <div class="col-sm-9">
      <input type='text' name='dataType' id='dataType' data-table="type" class='form-control autoListData' tabindex="5"/>
    </div>
  </div>

  <div class='form-group'>
    <label class="control-label col-sm-3">Комментарии:</label>
    <div class="col-sm-9">
      <input type='text' name='dataComment' id='dataComment' class='form-control autoClear' tabindex="6"/>
    </div>
  </div>

                    <input hidden type='text' name='previousSub' id='previousSub' />
                    <input hidden type='text' name='areaName' id='areaName' />
                    <input hidden type='text' name='dataId' id='dataId' />
                    <input hidden type='text' name='subId' id='subId' />
                    <input hidden type='text' name='loginName' id='loginName' />
                    <input hidden class="id"  type='text' name='raspredId' id='raspredId' />
                    <input hidden class="id"  type='text' name='typeId' id='typeId' />
                    <input hidden type='text' name='areaId' id='areaId' />
                    <!-- <input type='text' name='datasubupdate' id='datasubupdate' readonly/> -->
                    <button type='button' class='btn btn-success' onclick='dataExecute()' name='buttonDataExecute' id='buttonDataExecute'/></button>
                    <button type='button' class='btn btn-danger' onclick='dataClear()' name='buttonDataClear' id='buttonDataClear'/></button>
</form>

                      </div>


                      <div class='modal-footer'>
                      <button type='button' class='btn btn-default' data-dismiss='modal'>Закрыть</button>
                    </div>

</div></div></div>
