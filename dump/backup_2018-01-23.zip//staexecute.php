<?php
require 'connect.php'; // подключаем скрипт
$data=$_POST;
$tablename = $_POST["tablename"];
$columnname = $_POST["columnname"];
$newvalue = $_POST["newvalue"];
$idname = $_POST["idname"];
$name = $_POST["name"];
$modal = '';
$errors=array();
$output = '';
$message='';


if (($_POST["idname"])!=''){

// $message= '<div class="alert alert-danger" role="alert">TEST</div>';
//     echo ($message);
if (R::count($tablename, ''.$columnname.'=?', [$newvalue])>0) {
    $errors[]=$newvalue.' : Значение существует';
  }
if (empty($errors)) {
$value=R::load($tablename, $idname);
$value->$columnname=$newvalue;
R::store($value);
$message= '<div class="alert alert-info" role="alert">Обновили. Новое значение: '.$newvalue.'</div>';
// echo ($message);
lookoutput($tablename, $columnname, $name, $message);

} else
  {
    $message= '<div class="alert alert-danger" role="alert">Ошибка обновления: '.array_shift($errors).'</div>';
    // echo ($message);
    lookoutput($tablename, $columnname, $name, $message);
  }
  //echo ($message);
} 
elseif (isset($_POST["columnname"])) {

// $errors=array();
// $output = '';
// $message='';
if (R::count($tablename, ''.$columnname.'=?', [$newvalue])>0) {
    $errors[]=$newvalue.' : Значение существует';
  }
if (empty($errors)) {
$value=R::dispense($tablename);
$value->$columnname=$newvalue;
R::store($value);
$message= '<div class="alert alert-info" role="alert">Добавлено новое значение: '.$newvalue.'</div>';
// echo ($message);
lookoutput($tablename, $columnname, $name, $message);

} else
  {
    $message= '<div class="alert alert-danger" role="alert">Ошибка добавления новой записи: '.array_shift($errors).'</div>';
    // echo ($message);
    lookoutput($tablename, $columnname, $name, $message);
  }
//echo ($message);
}

function lookoutput($tablename, $columnname, $name, $message)
{
  $output='';
  $modal = '';



$beans=R::getAll( 'SELECT * FROM '.$tablename.'');

$output= '
       <div class="table-responsive" id="employee_table">
       <h3>Таблица '.$name.'</h3>
           <table class="table table-bordered table-hover header-fixed table-fixed">
           <thead>
                <tr>
                    <th>ID</th>
                     <th>'.$name.'</th>

                </tr>
                </thead>
                <tbody>';
foreach ($beans as $row) {
   $output .= '
                <tr>

                     <td>'.$row['id'].'</td>
                     <td><a href="#" onclick="updateStaData(this)" data-idname="'.$row['id'].'" data-value="'.$row[$columnname].'" data-idinput="'.$idinput.'" class="tablecolumn">'.$row[$columnname].'</a></td>
                </tr>
           ';
}
$output.= '  <!-- Modal -->
  <div class="myModal modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Результат обработки</h4>
        </div>
        <div class="modal-body">
          '.$message.'
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" onclick="closeMyModal()">Закрыть</button>
        </div>
      </div>
      
    </div>
  </div>';
echo($output);
//echo($modal);


// echo ($message);
}
?>
