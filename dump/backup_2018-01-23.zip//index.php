<?php
/**
* Защищенная страница. К ней возможен доступ только авторизованным
* пользователям. Если пользователь не авторизован, ему предлагается
* авторизоваться, и доступ к сайту ограничивается.
*/
require "connect.php";//параметры соединения
//require "zapr.php";
if(isset($_SESSION['loginUser'])):
  ?>
  <!DOCTYPE html>
  <html>
  <head>
    <title id="kross">АРМ КРОСС</title>
    <meta http-equiv="Cache-Control" content="no-cache" />
    <meta http-equiv="Cache-Control" content="max-age=3600, must-revalidate" />
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="shortcut icon" href="/images/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="/css/bootstrap.css" />
    <!-- <link rel="stylesheet" href="/css/pagination.css" /> -->
    <link rel="stylesheet" href="/css/mystyle.css" />
    <script src="/js/jquery-3.2.1.min.js"></script>
    <script src="/js/bootstrap.min.js"></script>
    <script src="/js/highlight.js"></script>
    <script src="/js/myjs.js"></script>
  </head>

  <body>
    <nav class="navbar navbar-inverse">
      <div class="container-fluid">
        <div class="navbar-header">
          <a class="navbar-brand" href="#" onclick="fetchData(1)">Кроссовый Журнал</a>
        </div>

        <!-- <div class="collapse navbar-collapse" id="myNavbar"> -->
          <ul class="nav navbar-nav navbar-right">
            <li class="place navbar-form" id="area">
              <?php require_once 'list_area.php'; ?>
            </li>
            <li ><a href="#" onclick="fetchData(1)">Домой <span class="glyphicon glyphicon-home"></span></a></li>
            <li ><a href="#" onclick="readBid(1)" id="counthref">Заявки</a><span class="label label-info" id="countbid"></span></li>

            <li class="dropdown">
             <a class="dropdown-toggle" data-toggle="dropdown" href="#">Справочник
              <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li class="dropdown-header">Работа со справочником</li>
                <li><a href="#" onclick="catalogOpen()"><span>Справочник телефонов</span></a></li>
                <li><a href="#" onclick="catalogEdit(1)"><span>Редактировать справочник</span></a></li>
                <!-- <li><a href="#" onclick="catalogFreeNumber()"><span>Свободные номера</span></a></li> -->
              </ul>
            </li>
            <li class="dropdown">
             <a class="dropdown-toggle" data-toggle="dropdown" href="#">Лог
              <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li class="dropdown-header">Логи операций с данными</li>
                <li><a href="#"  onclick="readLogData(1)"><span>Лог Данных</span></a></li>
                <hr>
                <li class="dropdown-header">Логи операций со справочником</li>
                <li><a href="#"  onclick="readLogCatalog()"><span>Лог Справочника</span></a></li>
              </ul>
            </li>

            <li class="dropdown">
              <a class="dropdown-toggle" data-toggle="dropdown" href="#">БД
               <span class="caret"></span></a>
               <ul class="dropdown-menu">
                <li class="dropdown-header">Редактировать списки</li>
                <li><a href="#" onclick=" staCRUD('sub', 'Абоненты')"><span>Абоненты</span></a></li>
                <li><a href="#" onclick=" staCRUD('unit', 'Управления')"><span>Управления</span></a></li>
                <li><a href="#" onclick=" staCRUD('department', 'Отделы/Бюро')"><span>Отделы/Бюро</span></a></li>
                <li><a href="#" onclick=" staCRUD('filial', 'Филиалы')"><span>Филиалы</span></a></li>
                <li><a href="#" onclick=" staCRUD('area', 'Площадки')"><span>Площадки</span></a></li>
                <li><a href="#" onclick=" staCRUD('type', 'Типы')"><span>Типы</span></a></li>
                <li><a href="#" onclick=" staCRUD('raspred', 'Распределение')"><span>Распределение</span></a></li>
                <li><a href="#" onclick=" staCRUD('number', 'Свободные номера')"><span>Свободные номера</span></a></li>
              </ul>
            </li>
          </li>

          <li class="dropdown admin" >
            <a class="dropdown-toggle" data-toggle="dropdown" href="#">Admin
              <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="#" onclick="stats()"><span>Статистика просмотра справочника</span></a></li>
                <li><a href="/dump/dump_baza.php" ><span>Сделать резервную копию БД</span></a></li>
                <!-- <li><a href="#" id="sig"><span>Сигнализация</span></a></li>
                <li><a href="#" id="napolnenie"><span>Наполнение справочника</span></a></li> -->
                <li><a href="signup.php" id="registration"><span>Зарегистрировать пользователя</span></a></li>
              </ul>
            </li>
            <li ><a href="#" id="printt">Печать <span class="glyphicon glyphicon-print"></span></a></li>
            <li><a href="#" onclick="exitKross()">Выход <span class="glyphicon glyphicon-off"></span></a></li>
          </ul>
        <!-- </div> -->
      </div>
    </nav>

    <div class="container-fluid text-center">    
      <div class="row content">
<!--     <div class="col-sm-2 sidenav">
      <p class="well"><a href="#">Link</a></p>
      <p class="well"><a href="#">Link</a></p>
      <p class="well"><a href="#">Link</a></p>
    </div> -->
    <div class="col-md-12 text-left"> 
      <!-- <input class="form-control" id="myInput" type="text" placeholder="Search.."> -->
      <!--  <h1>Welcome</h1> -->
      <div class="row" id="top_header_left"></div>
      <div class="row" id="poisk"></div>
      

      <div id="container_p"></div>
      <hr>
      <h3>Test</h3>
      <p>Lorem ipsum...</p>
     
      
    </div>
<!--     <div class="col-sm-1 sidenav">
      <div class="well">
        <p>ADS</p>
      </div>
      <div class="well">
        <p>ADS</p>
      </div>
    </div> -->
  </div>
</div>

<footer class="container-fluid text-left well">
  <div class="col-md-4"><h3>Контакты</h3><hr>
    Транзистор Кросс 3222<br />
    Мион Кросс 5133<br/>
    Дзержинка Кросс 5811<br/><br/>
  </div>
  <div class="col-md-4"><h3>Просмотры справочника</h3><hr>
     <?php include 'show_stats.php';?>
  </div>
  <div class="col-md-4"><h3>Работает</h3><hr><p id="login"><?php echo $_SESSION["login"];?></p>
    <p>IP: <?php echo $_SERVER["REMOTE_ADDR"]; ?></p></div>
    <div id="adm" hidden><?php echo $_SESSION["admin"];?></div><?php echo $hostname; ?>
  </div>
  <div class="col-md-12" id="copywriteblock">ADragunov</div>
</footer>
<!-- <div class="col-md-12" id="copywriteblock">Dragunov</div> -->
<!-- <script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#container_p tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script> -->
</body>
</html>
<?php
require('modal.php');
?>
<?php else:?>
  <script>window.location="login.php";</script>
  <!--a href="login.php">Авторизация</a-->
<?php endif;?>