<?php  require_once 'connectsql.php';?>
<!--Форма поиска-->
<div class="row">
  <form class="form-horizontal"  method="post" action="" name="form_poisk" id="form_poisk">
    <div class="col-md-4">
      <select class="form-control" size="1" name="paramPoisk" id="paramPoisk">
        <option  value="data" >Данные</option>
        <option  selected  value="number">Телефон</option>
        <option  value="sub_name" >Имя</option>
      </select>
    </div>
    <div class="form-group col-md-8">
     <div class="form-group col-md-11">
       <input type="text" class="form-control" rows="1" cols="25" type="text" name="searchString" id="searchString" autofocus placeholder="Что ищем?"></div>
       <div class="form-group col-md-1"><input class="btn btn-default" type="submit" value="Поиск" id="select_poisk"/></div>
     </div>  



<!--    <div class="form-group">
  <div class="input-group">
  <span class="input-group-addon">Поиск</span>
  <input type="text" name="searchString" id="searchString" placeholder="Поиск кроссовому журналу" class="form-control" autofocus />
  </div>
</div> -->
</form>
</div>



<!-- <div class="form-group">
  <div class="input-group">
  <span class="input-group-addon">Поиск</span>
  <input type="text" name="searchString" id="searchString" placeholder="Поиск по логу кроссового журнала" class="form-control" />
  </div>
  </div> -->