<?php
// exec('mysqldump --user=dron --password=port2100 --host=192.168.0.101 kross > ' . date('Y-m-d') . '.sql');
print_r(phpinfo());
?>