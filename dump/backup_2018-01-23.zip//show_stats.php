<?require_once 'connect.php'; // подключаем скрипт
// Указываем кодировку, в которой будет получена информация из базы
// Извлекаем статистику по текущей дате (переменная date попадает сюда из файла count.php, который, в свою очередь, подключается в каждом из 4 обычных файлов)
$date = date("Y-m-d");
$res = R::getAll('SELECT views, hosts FROM visits WHERE date=?', [$date]);

 foreach($res as $row)
  {
echo '<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="employees">
                    <p class="counter-count">'.$row['views'].'</p>
                    <p class="employee-p">Просмотров</p>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="employees">
                    <p class="counter-count">'.$row['hosts'].'</p>
                    <p class="employee-p">Уникальные</p>
                </div>
            </div>';
}
?>