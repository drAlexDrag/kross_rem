 <div id='staCrudModal' class='mymodal fade'>
  <div class='mymodal-dialog'>
   <div class='mymodal-content'>
    <div class='mymodal-header'>
     <button type='button' class='close' data-dismiss='modal'>&times;</button>
     <h4 class='mymodal-title' id='staCrudTitle'></h4>
   </div>

   <div class='mymodal-body'>
     <form  method="post" id="staCrudForm" class="form-horizontal">


      <div class='form-group autoList' id="autoListClass">
       <div class="col-sm-6"><label class="control-label " id="labelheader"></label></div>
        <!-- <div class="col-sm-6"> -->
          <!-- <input type='text' name='staCrudInsert' id='staCrudInsert' data-table='asd' class='form-control input-sm autoListData'/></div> -->
          <div class="col-sm-6">
            <input type="checkbox" name="operation" id="newValue"> Добавить как новое
          </div>
        </div><div class="col-sm-12" id="out" style="color: blue"></div>

        <div class='form-group'>
  <div class="col-sm-12">
          <input type='text' name='staAutoList' id='staAutoList' data-table='asd'  class='form-control input-sm autoListData'/>
        </div>
</div>

<div class='form-group' id="outCrudModal"><!-- <div class="col-sm-12" id="out"></div> --></div>




<div class='form-group'>
  <div class="col-sm-6">
        <input hidden id='tablename' />
        <input hidden id='columnname' />
        <input hidden id='headername' />
        <input hidden id='idname' />
      </div>
    </div>
    <!--     <hr> -->
        <!-- <button type='button' class='btn btn-success' onclick="staExecute()" id="buttonExecute">Добавить</button>
        <button type='button' class='btn btn-success' onclick='staExecuteUpdate()' id='buttonUpdate'>Внести изменение</button> -->
      </form>
    </div>

    <div class='mymodal-footer'>

      <div class="btn-group">
      <button type='button' class='btn btn-success btn-block' onclick="staExecute()" id="buttonExecute">Обработать</button>
      
      <button type='button' class='btn btn-danger btn-block' onclick="staDelete()" id="buttonDelete">Удалить</button>
        <!-- <button type='button' class='btn btn-success' onclick='staExecuteUpdate()' id='buttonUpdate'>Внести изменение</button> -->
      <!-- <input class="btn btn-primary" type="submit" name="doStaCrudModal" id=doStaCrudModal" value="Зарегистрироваться" /> -->
    <!--  <button type='button' class='btn btn-default btn-block' data-dismiss='modal'>Закрыть</button> -->
</div>

   </div>
 </div>
</div>




</div>



<!-- Modal -->
<div class="mymodal modal fade" id="myModalDelete" role="dialog">
  <div class="mymodal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title" id="titleDelete"></h4>
      </div>
      <div class="modal-body">
        <form  method="post" id="staDeleteForm" class="form-horizontal">
          
           <div class="col-sm alert alert-info" id="idLabelDelete"></div>
          <div class="col-sm" id="outDelete"></div>

        </form>
      </div>
      <div class="modal-footer">
        <button type='button' class='btn btn-danger btn-block' onclick="deleteEntry()" id="deleteEntry">Точно удалить?</button>
        <button type="button" class="btn btn-default btn-block" onclick="closeMyModalDelete()">Закрыть</button>
      </div>
    </div>

  </div>
</div>