<?php
require "libs/rb.php";
R::setup( 'mysql:host=localhost;dbname=kross',
        'dron', 'port2100' ); //for both mysql or mariaDB
session_start();
?>