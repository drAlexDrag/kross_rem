<?php
require_once 'connect.php'; // подключаем скрипт
$id_message=$_POST["id_message"];
if (isset($_POST["id_message"])) {
 $output = '';
 // $sql =( "SELECT * FROM message  WHERE id=".$id_message."");
 $message = R::getAll('SELECT * FROM message  WHERE id=?', [$id_message]);
 // $result = mysqli_query($connect, $sql);
 $output .= '
 <div class="table-responsive" id="message_table">
 <h4>Запрос  на внесение изменений в справочник</h4>
 <table class="table table-bordered">
 <thead>
 <tr>
 <th hidden>id message</th>
 <th hidden>Дата</th>
 <th hidden>ip_message</th>
 <th>ID Абонента</th>
 <th>Абонент</th>
 <th>Внутренний</th>
 <!--th>Городской</th-->
 <th>Управление</th>
 <th>Отдел/Бюро</th>
 <th>Кабинет</th>
 <th>Филиал</th>
 <th>Сообщение</th>
 <th>Обработано</th>
 </tr></thead>';

 foreach($message as $row)
 {
   $output .= '
   <tr>
   <td class="select_message" data-id_catalog="'.$row["id_catalog"].'"  data-id_message="'.$row["id"].'" style="background:  #CDC5BF" hidden>'.$row["id"].'</td>
   <td id="date_message" hidden>'.$row["date"].'</td>
   <td id="ip_message" hidden>'.$row["ip_message"].'</td>
   <td>'.$row["id_catalog"].'</td>
   <td>'.$row["sub"].'</td>
   <td>'.$row["vnutr"].'</td>
   <!--td>'.$row["city"].'</td-->
   <td>'.$row["unit"].'</td>
   <td>'.$row["department"].'</td>
   <td>'.$row["cabinet"].'</td>
   <td>'.$row["filial"].'</td>
   <td>'.$row["message"].'</td>
   <td><button type="button" name="btn_obr" id="btn_obr" class="btn btn-xs btn-success btn_obr btn-block" data-id="'.$row["id"].'">Готово</button></td>
   </tr>Запрос-№'.$row["id"].' IP-'.$row["ip_message"].' Дата запроса '.$row["date"].'
   ';
   
 //$output .= ' <script>$("#spr").html("<p>'.$row["date_message"].'</p>");</script>';

 }
 
 $output .= '</table>
 </div>';
 echo $output;
}
else{
 $output .= '
 <br><div class="alert alert-info">
 <strong>Info!</strong>Нет необработанных запросов</div>';
}
$output .= '</table>
</div>';
// echo $output;

?>
