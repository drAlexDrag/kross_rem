<?php
require 'connect.php';
$output = '';
 if($_POST['page'])
{
$area=$_POST["area"];
$page = $_POST['page'];
$cur_page = $page;
$page -= 1;
$per_page = 25; // Per page
$previous_btn = true;
$next_btn = true;
$first_btn = true;
$last_btn = true;
$start = $page * $per_page;

/* Total Count */
$areaid=R::findOne( 'area', ' area_name = ? ', [ $area ] );
$count=R::count('krossdata', ' area_id = ? ', array($areaid->id));
 
$no_of_paginations = ceil($count / $per_page);
/* ---------------Calculating the starting and endign values for the loop----------------------------------- */
if ($cur_page >= 7) {
    $start_loop = $cur_page - 3;
    if ($no_of_paginations > $cur_page + 3)
        $end_loop = $cur_page + 3;
    else if ($cur_page <= $no_of_paginations && $cur_page > $no_of_paginations - 6) {
        $start_loop = $no_of_paginations - 6;
        $end_loop = $no_of_paginations;
    } else {
        $end_loop = $no_of_paginations;
    }
} else {
    $start_loop = 1;
    if ($no_of_paginations > 7)
        $end_loop = 7;
    else
        $end_loop = $no_of_paginations;
}
/* ----------------------------------------------------------------------------------------------------------- */
include('pagination.php');
$beans = R::getAll('SELECT krossdata.data, krossdata.raspred_id, raspred.raspred_name, krossdata.number, krossdata.sub_id, sub.sub_name, sub.id, type.type_name, krossdata.comment, area.area_name
FROM krossdata
INNER JOIN raspred ON krossdata.raspred_id = raspred.id
INNER JOIN sub ON krossdata.sub_id = sub.id
INNER JOIN type ON krossdata.type_id = type.id
INNER JOIN area ON krossdata.area_id = area.id
WHERE area.area_name=?
ORDER BY krossdata.data ASC LIMIT ?, ?', [ $area, $start, $per_page ]);
//var_dump($beans);
$output .= '
       <div class="table-responsive" id="employee_table">
           <table class="table table-bordered table-hover header-fixed table-fixed">
           <thead>
                <tr>
                    <th>Данные</th>
                     <th>Распределение</th>
                     <th style="width:12%;">Номер</th>
                     <th>Имя по справочнику</th>
                     <th>Тип</th>
                     <th>Комментарии</th>
                     <th>Имя по Кроссам</th>
                     <th>Площадка</th>
                </tr>
                </thead>
                <tbody>';
 foreach($beans as $row)
 {
  switch ($row["type_name"]) {
          case 'Прямая':
            $color='class="w3-aqua"';
            break;
          case 'Сигнализация':
            $color='class="w3-blue"';
            break;
          case 'Часы':
            $color='class="w3-violet"';
            break;
          case 'Телефон':
            $color='class="w3-lime2"';
            break;
          case 'Земля':
            $color='class="w3-olive"';
            break;
          case 'Обрыв':
            $color='class="w3-red"';
            break;
            case 'Свободный':
            $color='class="w3-yellow"';
            break;
          case 'Сирена':
            $color='class="w3-navy"';
            break;
          default:
            $color='';
            break;
          }
  $output .= '
                <tr '.$color.'>
                     <td  class="edit_data"  data-subid="'.$row["sub_id"].'" data-idxxx="'.$row["data"].'" data-idarea="'.$row["area_name"].'" title="Выбрать для редактирования"><b>'.$row["data"].' </b><span class="glyphicon glyphicon-edit"></span></td>
                     <td data-f="'.$row["data"].'" >'.$row["raspred_name"].'</td>
                     <td class="data-number" data-number="'.$row["data"].'" data-idnumber="'.$row["number"].'" title="Быстрый поиск по номеру: '.$row["number"].'">'.$row["number"].' <span class="glyphicon glyphicon-search"></span></td>
                     <td data-sub="'.$row["sub_name"].'" data-name="'.$row["data"].'" title="ID абонента-'.$row["sub_id"].'">'.$row["sub_name"].'</td>
                     <td data-type="'.$row["data"].'" >'.$row["type_name"].'</td>
                     <td data-comment="'.$row["data"].'" >'.$row["comment"].'</td>
                     <td data-comment="'.$row["data"].'" >'.$row["name_xxx"].'</td>
                     <td data-comment="'.$row["data"].'" >'.$row["area_name"].'</td>
                </tr>
           ';
 }

$output .= '</tbody></table></div>';
if ($beans==null){$output=''; $output='<br><div class="alert alert-info">
  <strong>Info!</strong> Данные по '.$area.' не найдены.
</div>';}
echo $output;
}
 ?>
